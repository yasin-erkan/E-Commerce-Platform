//The function to get products from API
export const fetchProducts = async () => {
  try {
    const response = await fetch("db.json");

    //if there is no 'error', convert the data!!
    if (!response.ok) {
      throw new Error("Wrong URL");
    }
    return await response.json();
  } catch (error) {
    console.log(`Error: ${error}`);
    return [];
  }
};
//the function that let us render the products
export const renderProducts = (products, addToCartCallBack) => {
  // To draw from html the scope in which the products will be rendered//
  const productList = document.querySelector("#product-list");
  //creating product-list content//
  productList.innerHTML = products
    .map(
      (product) =>
        `
  <div class="product">
          <img src="${product.image}" alt="product" class="product-img">
          <div class="product-info">
            <h2 class="product-title">${product.title}</h2>
            <p class="product-price">$${product.price}</p>
            <a class="add-to-cart" data-id='${product.id}'>Add to chart</a>
          </div>
        </div>
    `
    )
    .join(""); //We left a space ("") to remove the commas between the strings and with the method '.join' //

  //choose 'add-to-chart' buttons
  const addToCartButtons = document.getElementsByClassName("add-to-cart");
  for (let i = 0; i < addToCartButtons.length; i++) {
    const addToCartButton = addToCartButtons[i];
    addToCartButton.addEventListener("click", addToCartCallBack);
  }
};
