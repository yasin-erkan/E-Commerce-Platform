import { addToCart, displayCartTotal, renderCartItems } from "./cart.js";
import { fetchProducts, renderProducts } from "./product.js";
import { getFromLocalStorage, updateCartIcon } from "./utils.js";

const menuIcon = document.querySelector("#menu-icon");
const menu = document.querySelector(".navbar");

menuIcon.addEventListener("click", () => {
  menu.classList.toggle("open-menu");
});

//We need to get the products from the API while on the home page. For this, we follow the browser path with window.location and decide//
document.addEventListener("DOMContentLoaded", async () => {
  let cart = getFromLocalStorage();
  if (window.location.pathname.includes("cart.html")) {
    //Cart page//
    console.log("Cart Page");
    renderCartItems();
    displayCartTotal();
  } else {
    // HomePage//
    console.log(`Home Page`);
    const product = await fetchProducts();
    renderProducts(product, (event) => {
      addToCart(event, product);
    });
  }

  updateCartIcon(cart);
});

//only bring us data if we are on the homepage//
