import {
  calculateCartTotal,
  getFromLocalStorage,
  saveToLocalStorage,
  updateCartIcon,
} from "./utils.js";

let cart = getFromLocalStorage();
//the function to add product in the basket//
export const addToCart = (event, products) => {
  const productId = parseInt(event.target.dataset.id);
  const product = products.find((product) => product.id === productId);
  if (product) {
    const existingItem = cart.find((item) => item.id === productId);
    //if the product exist in the basket, add 1 //
    if (existingItem) {
      existingItem.quantity++;
    } else {
      const cartItem = {
        id: product.id,
        title: product.title,
        price: product.price,
        image: product.image,
        quantity: 1,
      };

      cart.push(cartItem);
      //Update the content of the added cart
      event.target.textContent = "Added";
      saveToLocalStorage(cart);
      updateCartIcon(cart);
    }
  }
};

const removeFromCart = (event) => {
  const productID = parseInt(event.target.dataset.id);
  //We need a unique value for each element to be deleted. Here, we access the id of each element
  cart = cart.filter((item) => item.id !== productID);
  //removed the clicked item from the cart
  saveToLocalStorage(cart); //update localStorage
  renderCartItems(); //update page
  displayCartTotal(); //update total quantity
  updateCartIcon(cart); //update basket
};

export const renderCartItems = () => {
  const cartItemsElement = document.querySelector("#cartItems");
  cartItemsElement.innerHTML = cart
    .map(
      (item) => `
  
     <div class="cart-item">
              <img
                src="${item.image}"
                alt=""
              />
              <!-- Info -->
              <div class="cart-item-info">
                <h2 class="cart-item-title">${item.title}</h2>
                <input
                  type="number"
                  min="1"
                  value=${item.quantity}
                  class="cart-item-quantity"
                  data-id='${item.id}'
                />
              </div>
              <h2 class="cart-item-price">$${item.price}</h2>
              <button class="remove-from-cart" data-id='${item.id} '>Remove</button>
            </div>
  `
    )
    .join("");
  // reach to the "remove from chart " buttons"
  const removeButtons = document.querySelectorAll(".remove-from-cart");
  for (let i = 0; i < removeButtons.length; i++) {
    const removeButton = removeButtons[i];
    removeButton.addEventListener("click", removeFromCart);
  }

  const quantityInputs = document.querySelectorAll(".cart-item-quantity");

  for (let i = 0; i < quantityInputs.length; i++) {
    const quantityInput = quantityInputs[i];
    quantityInput.addEventListener("change", onQuantityChange);
  }
};

const onQuantityChange = (event) => {
  const newQuantity = +event.target.value;
  const productID = +event.target.dataset.id;

  if (newQuantity > 0) {
    const cartItem = cart.find((item) => item.id === productID);
    if (!cartItem) return;
    cartItem.quantity = newQuantity;
    saveToLocalStorage(cart);
    displayCartTotal();
    updateCartIcon(cart);
  }
};

export const displayCartTotal = () => {
  const cartTotalElement = document.querySelector("#cartTotal");
  const total = calculateCartTotal(cart);
  cartTotalElement.textContent = `Total: ${total.toFixed(2)}`;
};
